# package

__version__ = "2.0.8"  # dont forget to update version in setup.py as well

from geventhttpclient.client import HTTPClient
from geventhttpclient.url import URL
