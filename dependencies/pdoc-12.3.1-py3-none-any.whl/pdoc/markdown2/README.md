This directory includes a vendored copy of [markdown2](https://pypi.org/project/markdown2/) taken from
[here](https://github.com/mhils/python-markdown2/tree/37ebca573159c25c110c0a387453b10129ce1688).
