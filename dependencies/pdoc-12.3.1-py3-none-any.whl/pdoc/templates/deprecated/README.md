# Deprecated Template Files

This directory contains files that used to be part of pdoc's default template, but have been deprecated (or moved).
To ease migration for users with custom templates, pdoc looks up templates in `deprecated/` as a last resort.
Templates in `deprecated/` then print a warning message prompting users to upgrade.
