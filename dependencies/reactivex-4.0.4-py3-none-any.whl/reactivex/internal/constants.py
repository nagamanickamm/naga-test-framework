from datetime import datetime, timedelta

DELTA_ZERO = timedelta(0)
UTC_ZERO = datetime.utcfromtimestamp(0)
